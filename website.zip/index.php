<?php
include 'includes/header.php';
?>

<main role="main">
	<div>
		<h4>Hello World</h4>
	</div>
</main>


<?php include 'includes/footer.php'; ?>